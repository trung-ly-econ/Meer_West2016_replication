ReadMe date: August 19, 2015

*--------------------*
*      OVERVIEW      *
*--------------------*

Included in this folder are the data and Stata code used in:

Meer, Jonathan and Jeremy West (2015). "Effects of the Minimum Wage on Employment Dynamics." Journal of Human Resources: Forthcoming.

The article should be included in this download and is also available at: http://econweb.tamu.edu/jmeer/research.html

The .do files were executed using Stata version 13, but should be fine for at least Stata version 10+ with the exception of the "xtabond2" user-compiled command, which may not function properly with older versions of Stata.


*--------------------*
*    REPLICATION     *
*--------------------*

To replicate the results from the article, use the respective Stata .do files. Note that the user-provided packages: "estout", "ivreg2", and "xtabond2" are required by the code (available from within Stata by typing, e.g., "ssc install estout" or at http://repec.org/bocode/e/estout/esttab.html). The dataprep folder contains code and original (raw) data files and is not necessary in order to simply replicate results from the article.


*--------------------*
*    DATA SOURCES    *
*--------------------*

This download includes "minimal" versions of the data sets used in estimations. For details on downloading the raw data files, as well as the data sources, see the included DataSources.txt file.
