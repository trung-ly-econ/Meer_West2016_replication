#!/bin/bash

# Last modified: January 20, 2015

# NOTE: the BLS recently updated their ftp website for hosting the QCEW files, and the below may be outdated.

# Download the BDS, QCEW, QWI, and CPS-MORG data in a Linux console. See the DataSources.txt file for details.
# Run in Linux terminal via the command: sh download_bds_qcew_qwi_morg.sh

# Note that these data files are fairly large, requiring about 55GB of total hard drive space and 12GB of Internet bandwidth.

# The three pre-1990 SIC-based QCEW files are in .dbf format. This script uses a perl XBase command to convert them to .csv
# Use your package manager to install perl-DBD-XBase (e.g. yum install perl-DBD-XBase) before running this script


# BDS - Bureau of the Census

wget -N --timestamping http://www2.census.gov/ces/bds/estab/bds_e_st_release.csv


# QCEW - Bureau of Labor Statistics

wget -N --timestamping ftp://ftp.bls.gov/pub/special.requests/cew/sic/history/state/st751814.zip
wget -N --timestamping ftp://ftp.bls.gov/pub/special.requests/cew/sic/history/state/st821874.zip
wget -N --timestamping ftp://ftp.bls.gov/pub/special.requests/cew/sic/history/state/st881944.zip

unzip -o st751814.zip
dbfdump.pl --fs "," st751814.dbf > st751814.csv

unzip -o st821874.zip
dbfdump.pl --fs "," st821874.dbf > st821874.csv

unzip -o st881944.zip
dbfdump.pl --fs "," st881944.dbf > st881944.csv

for i in {1990..2012} ; do
	wget -N --timestamping ftp://ftp.bls.gov/pub/special.requests/cew/beta/$i/$i.q1-q4.singlefile.zip
	unzip -o $i.q1-q4.singlefile.zip
done


# QWI - Bureau of the Census (hosted at Cornell University)

array2013Q1=( al ak az ar ca co ct de ga hi id il in ia ks ky la me md mi mn ms mo mt ne nv nh nj nm ny nc nd oh ok pa ri sc sd tn tx ut vt va wa wv wi wy )
array2012Q4=( fl or )

for i in "${array2013Q1[@]}" ; do
	wget -N --timestamping http://download.vrdc.cornell.edu/qwipu/R2013Q1/$i/wia/qwi'_'$i'_'wia_wib_naics3_all.csv.gz
	gunzip -f < qwi'_'$i'_'wia_wib_naics3_all.csv.gz > qwi'_'$i'_'wia_wib_naics3_all.csv
done

for i in "${array2012Q4[@]}" ; do
	wget -N --timestamping http://download.vrdc.cornell.edu/qwipu/R2012Q4/$i/wia/qwi'_'$i'_'wia_wib_naics3_all.csv.gz
	gunzip -f < qwi'_'$i'_'wia_wib_naics3_all.csv.gz > qwi'_'$i'_'wia_wib_naics3_all.csv
done


# QWI - Bureau of the Census (hosted at Cornell University) - "se" version (includes education but not age or race) -- downloading by NAICS sector only

array2013Q1=( al ak az ar ca co ct de ga hi id il in ia ks ky la me md mi mn ms mo mt ne nv nh nj nm ny nc nd oh ok pa ri sc sd tn tx ut vt va wa wv wi wy )
array2012Q4=( fl or )

for i in "${array2013Q1[@]}" ; do
	#wget -N --timestamping http://download.vrdc.cornell.edu/qwipu/R2013Q1/$i/se/qwi'_'$i'_'se_wib_naicssec_all.csv.gz
	gunzip -f < qwi'_'$i'_'se_wib_naicssec_all.csv.gz > qwi'_'$i'_'se_wib_naicssec_all.csv
done

for i in "${array2012Q4[@]}" ; do
	#wget -N --timestamping http://download.vrdc.cornell.edu/qwipu/R2012Q4/$i/se/qwi'_'$i'_'se_wib_naicssec_all.csv.gz
	gunzip -f < qwi'_'$i'_'se_wib_naicssec_all.csv.gz > qwi'_'$i'_'se_wib_naicssec_all.csv
done


# CPS-MORG - Bureau of the Census (hosted at NBER)

array=( 00 10 11 12)

for i in "${array[@]}" ; do
	wget -N --timestamping http://www.nber.org/morg/annual/morg$i.dta
done

mv morg00.dta morg2000.dta
mv morg10.dta morg2010.dta
mv morg11.dta morg2011.dta
mv morg12.dta morg2012.dta

for i in {1..9} ; do
	wget -N --timestamping http://www.nber.org/morg/annual/morg0$i.dta
	mv morg0$i.dta morg200$i.dta
done

for i in {79..99} ; do
	wget -N --timestamping http://www.nber.org/morg/annual/morg$i.dta
	mv morg$i.dta morg19$i.dta
done
